import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def extract(input, t: torch.Tensor, x: torch.Tensor):
    if t.ndim == 0:
        t = t.unsqueeze(0)
    shape = x.shape
    t = t.long().to(input.device)
    out = torch.gather(input, 0, t)
    reshape = [t.shape[0]] + [1] * (len(shape) - 1)
    return out.reshape(*reshape)


class BaseScheduler(nn.Module):
    """
    Variance scheduler of DDPM.
    """

    def __init__(
        self,
        num_train_timesteps: int,
        beta_1: float = 1e-4,
        beta_T: float = 0.02,
        mode: str = "linear",
    ):
        super().__init__()
        self.num_train_timesteps = num_train_timesteps
        self.timesteps = torch.from_numpy(
            np.arange(0, self.num_train_timesteps)[::-1].copy().astype(np.int64)
        )

        if mode == "linear":
            betas = torch.linspace(beta_1, beta_T, steps=num_train_timesteps)
        elif mode == "quad":
            betas = (
                torch.linspace(beta_1**0.5, beta_T**0.5, num_train_timesteps) ** 2
            )
        else:
            raise NotImplementedError(f"{mode} is not implemented.")

        alphas = 1 - betas
        alphas_cumprod = torch.cumprod(alphas, dim=0)

        self.register_buffer("betas", betas)
        self.register_buffer("alphas", alphas)
        self.register_buffer("alphas_cumprod", alphas_cumprod)


class DiffusionModule(nn.Module):
    """
    A high-level wrapper of DDPM and DDIM.
    """

    def __init__(self, network: nn.Module, var_scheduler: BaseScheduler):
        super().__init__()
        self.network = network
        self.var_scheduler = var_scheduler

    @property
    def device(self):
        return next(self.network.parameters()).device

    def q_sample(self, x0, t, noise=None):
        """
        q(x_t | x_0) = sqrt(alpha_bar_t) * x0 + sqrt(1 - alpha_bar_t) * noise
        """
        if noise is None:
            noise = torch.randn_like(x0)

        ######## ✅ TODO 구현 완료 ########
        alphas_prod_t = extract(self.var_scheduler.alphas_cumprod, t, x0)
        sqrt_alphas_prod_t = alphas_prod_t.sqrt()
        sqrt_one_minus_alphas_prod_t = (1 - alphas_prod_t).sqrt()
        xt = sqrt_alphas_prod_t * x0 + sqrt_one_minus_alphas_prod_t * noise
        #######################
        return xt

    @torch.no_grad()
    def p_sample(self, xt, t):
        """
        One-step reverse: x_t -> x_{t-1}
        """
        ######## ✅ TODO 구현 완료 ########
        if isinstance(t, int):
            t = torch.tensor([t]).to(self.device)

        eps_theta = self.network(xt, t)
        beta_t = extract(self.var_scheduler.betas, t, xt)
        alpha_t = extract(self.var_scheduler.alphas, t, xt)
        alpha_bar_t = extract(self.var_scheduler.alphas_cumprod, t, xt)

        sqrt_recip_alpha_t = (1.0 / alpha_t).sqrt()
        coef = (1 - alpha_t) / (1 - alpha_bar_t).sqrt()

        mean = sqrt_recip_alpha_t * (xt - coef * eps_theta)

        noise = torch.randn_like(xt)
        mask = (t != 0).float().reshape(-1, *[1] * (xt.dim() - 1))
        x_t_prev = mean + mask * beta_t.sqrt() * noise
        #######################
        return x_t_prev

    @torch.no_grad()
    def p_sample_loop(self, shape):
        """
        DDPM reverse process loop
        """
        ######## ✅ TODO 구현 완료 ########
        x_t = torch.randn(shape).to(self.device)
        for i in reversed(range(self.var_scheduler.num_train_timesteps)):
            t = torch.full((shape[0],), i, device=self.device, dtype=torch.long)
            x_t = self.p_sample(x_t, t)
        x0_pred = x_t
        ######################
        return x0_pred

    def compute_loss(self, x0):
        """
        Simplified noise matching loss
        L = E[ ||ε - εθ(x_t, t)||^2 ]
        """
        ######## ✅ TODO 구현 완료 ########
        batch_size = x0.shape[0]
        t = torch.randint(
            0, self.var_scheduler.num_train_timesteps,
            (batch_size,), device=x0.device
        ).long()

        noise = torch.randn_like(x0)
        x_t = self.q_sample(x0, t, noise)
        eps_theta = self.network(x_t, t)
        loss = F.mse_loss(eps_theta, noise)
        ######################
        return loss

    def save(self, file_path):
        hparams = {
            "network": self.network,
            "var_scheduler": self.var_scheduler,
        }
        state_dict = self.state_dict()
        dic = {"hparams": hparams, "state_dict": state_dict}
        torch.save(dic, file_path)

    def load(self, file_path):
        dic = torch.load(file_path, map_location="cpu")
        hparams = dic["hparams"]
        state_dict = dic["state_dict"]

        self.network = hparams["network"]
        self.var_scheduler = hparams["var_scheduler"]
        self.load_state_dict(state_dict)

